// app.js - Main application logic for Advanced Todo

document.addEventListener('DOMContentLoaded', () => {
    // DOM elements
    const inputBox = document.getElementById('input-box');
    const prioritySelect = document.getElementById('priority');
    const dueDateInput = document.getElementById('due-date');
    const addBtn = document.getElementById('add-btn');
    const searchBox = document.getElementById('search-box');
    const taskList = document.getElementById('task-list');
    const themeToggle = document.getElementById('theme-toggle');
    const progressBar = document.getElementById('progressBar');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const statusBtns = document.querySelectorAll('.status-btn');

    // Load tasks from localStorage
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    // Current filters
    let currentPriorityFilter = 'all';
    let currentStatusFilter = 'all';
    let searchQuery = '';

    // Initialize app
    init();

    function init() {
        loadTheme();
        renderTasks();
        updateProgress();

        // Event listeners
        addBtn.addEventListener('click', addTask);
        inputBox.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addTask();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'k') {
                e.preventDefault();
                searchBox.focus();
            }
        });
        
        searchBox.addEventListener('input', handleSearch);
        themeToggle.addEventListener('click', toggleTheme);

        filterBtns.forEach(btn => btn.addEventListener('click', handlePriorityFilter));
        statusBtns.forEach(btn => btn.addEventListener('click', handleStatusFilter));
    }

    function addTask() {
        const text = inputBox.value.trim();
        const priority = prioritySelect.value;
        const dueDate = dueDateInput.value;

        if (!text) {
            inputBox.focus();
            inputBox.style.borderColor = '#dc2626';
            setTimeout(() => {
                inputBox.style.borderColor = '';
            }, 2000);
            return;
        }

        const task = {
            id: Date.now(),
            text,
            priority,
            dueDate,
            completed: false,
            createdAt: new Date().toISOString()
        };

        tasks.unshift(task); // Add to beginning for most recent first
        saveTasks();
        renderTasks();
        updateProgress();

        // Clear inputs
        inputBox.value = '';
        dueDateInput.value = '';
        prioritySelect.value = 'high';
        inputBox.focus();
    }

    function renderTasks() {
        taskList.innerHTML = '';

        const filteredTasks = tasks.filter(task => {
            const matchesPriority = currentPriorityFilter === 'all' || task.priority === currentPriorityFilter;
            const matchesStatus = currentStatusFilter === 'all' ||
                (currentStatusFilter === 'completed' && task.completed) ||
                (currentStatusFilter === 'pending' && !task.completed);
            const matchesSearch = task.text.toLowerCase().includes(searchQuery.toLowerCase());

            return matchesPriority && matchesStatus && matchesSearch;
        });

        if (filteredTasks.length === 0) {
            const emptyMsg = document.createElement('li');
            emptyMsg.className = 'empty-message';
            emptyMsg.textContent = 'No tasks found';
            taskList.appendChild(emptyMsg);
            return;
        }

        filteredTasks.forEach(task => {
            const li = createTaskElement(task);
            taskList.appendChild(li);
        });
    }

    function createTaskElement(task) {
        const li = document.createElement('li');
        li.className = `task ${task.priority} ${task.completed ? 'done' : ''} ${isOverdue(task) ? 'overdue' : ''}`;
        li.dataset.taskId = task.id;

        const taskContent = document.createElement('div');
        taskContent.className = 'task-content';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', () => toggleTask(task.id));

        const textSpan = document.createElement('span');
        textSpan.textContent = task.text;
        textSpan.style.cursor = 'pointer';
        textSpan.addEventListener('click', () => toggleTask(task.id));

        taskContent.appendChild(checkbox);
        taskContent.appendChild(textSpan);

        // Add due date if exists
        if (task.dueDate) {
            const dueDateSpan = document.createElement('span');
            dueDateSpan.className = 'due-date';
            const date = new Date(task.dueDate + 'T00:00:00');
            dueDateSpan.textContent = `Due: ${date.toLocaleDateString()}`;
            taskContent.appendChild(dueDateSpan);
        }

        const actions = document.createElement('div');
        actions.className = 'task-actions';

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';
        editBtn.textContent = '✏️';
        editBtn.title = 'Edit task';
        editBtn.addEventListener('click', () => editTask(task.id));

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-btn';
        deleteBtn.textContent = '🗑️';
        deleteBtn.title = 'Delete task';
        deleteBtn.addEventListener('click', () => deleteTask(task.id));

        actions.appendChild(editBtn);
        actions.appendChild(deleteBtn);

        li.appendChild(taskContent);
        li.appendChild(actions);

        return li;
    }

    function toggleTask(id) {
        const task = tasks.find(t => t.id === id);
        if (task) {
            task.completed = !task.completed;
            saveTasks();
            renderTasks();
            updateProgress();
        }
    }

    function editTask(id) {
        const task = tasks.find(t => t.id === id);
        if (!task) return;

        const newText = prompt('Edit task:', task.text);
        if (newText !== null && newText.trim()) {
            task.text = newText.trim();
            saveTasks();
            renderTasks();
        }
    }

    function deleteTask(id) {
        if (confirm('Are you sure you want to delete this task?')) {
            tasks = tasks.filter(t => t.id !== id);
            saveTasks();
            renderTasks();
            updateProgress();
        }
    }

    function handlePriorityFilter(e) {
        filterBtns.forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        currentPriorityFilter = e.target.dataset.filter;
        renderTasks();
    }

    function handleStatusFilter(e) {
        statusBtns.forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        currentStatusFilter = e.target.dataset.status;
        renderTasks();
    }

    function handleSearch(e) {
        searchQuery = e.target.value;
        renderTasks();
    }

    function updateProgress() {
        const completedTasks = tasks.filter(t => t.completed).length;
        const totalTasks = tasks.length;
        const percentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
        progressBar.style.width = `${percentage}%`;
    }

    function isOverdue(task) {
        if (!task.dueDate || task.completed) return false;
        const dueDate = new Date(task.dueDate + 'T00:00:00');
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return dueDate < today;
    }

    function toggleTheme() {
        document.body.classList.toggle('dark');
        const isDark = document.body.classList.contains('dark');
        themeToggle.textContent = isDark ? '☀️' : '🌙';
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    }

    function loadTheme() {
        const theme = localStorage.getItem('theme');
        if (theme === 'dark') {
            document.body.classList.add('dark');
            themeToggle.textContent = '☀️';
        } else {
            themeToggle.textContent = '🌙';
        }
    }

    function saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }
});
