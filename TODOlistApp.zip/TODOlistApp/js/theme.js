const THEME_KEY = "todo_theme";

export function initTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === "dark") document.body.classList.add("dark");
}

export function toggleTheme() {
    document.body.classList.toggle("dark");
    const mode = document.body.classList.contains("dark") ? "dark" : "light";
    localStorage.setItem(THEME_KEY, mode);
}
