import { getTasks, saveTasks } from "./data.js";
import { renderTasks } from "./ui.js";
import { initTheme, toggleTheme } from "./theme.js";
import { updateProgress } from "./progress.js";
import { enableDragAndDrop } from "./dragdrop.js";
import { enableInlineEdit } from "./edit.js";




const form = document.getElementById("taskForm");
const filter = document.getElementById("filter");
const search = document.getElementById("search");
const themeBtn = document.getElementById("themeToggle");
const category = document.getElementById("category");

initTheme();

function refresh(tasks = getTasks()) {
    renderTasks(tasks);
    updateProgress(getTasks());
}

refresh();

themeBtn.onclick = toggleTheme;

form.onsubmit = e => {
    e.preventDefault();
    const title = taskInput.value.trim();
    if (!title) return;

    const tasks = getTasks();
    tasks.push({
        id: Date.now(),
        title,
        priority: priority.value,
        category: category.value,
        completed: false
    });

    saveTasks(tasks);
    refresh();
    form.reset();
};

taskList.onclick = e => {
    const li = e.target.closest(".task");
    if (!li) return;

    let tasks = getTasks();
    const task = tasks.find(t => t.id == li.dataset.id);

    if (e.target.classList.contains("delete")) {
        tasks = tasks.filter(t => t !== task);
    } else {
        task.completed = !task.completed;
    }

    saveTasks(tasks);
    refresh();
};

filter.onchange = () => {
    const tasks = getTasks();
    if (filter.value === "completed")
        refresh(tasks.filter(t => t.completed));
    else if (filter.value === "pending")
        refresh(tasks.filter(t => !t.completed));
    else refresh(tasks);
};

search.oninput = () => {
    const text = search.value.toLowerCase();
    refresh(getTasks().filter(t => t.title.toLowerCase().includes(text)));
};
enableDragAndDrop(document.getElementById("taskList"));

enableInlineEdit(document.getElementById("taskList"));

tasks.push({
    id: Date.now(),
    title,
    priority: priority.value,
    category: category.value,
    completed: false,
    dueDate: dueDate.value
});

const categorybtns = document.querySelectorAll("[data-category]");
categorybtns.forEach(btn => {
    btn.onclick = () => {
        const value = btn.dataset.category;
        const tasks = getTasks();
        if (value === "all") refresh(tasks);
        else refresh(tasks.filter(t => t.category === value));
    };

});