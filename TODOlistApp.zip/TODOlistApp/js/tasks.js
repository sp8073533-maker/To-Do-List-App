import { getTasks, saveTasks } from "./data.js";

export function addTask(task) {
    const tasks = getTasks();
    tasks.push(task);
    saveTasks(tasks);
}

export function deleteTask(id) {
    let tasks = getTasks();
    tasks = tasks.filter(task => task.id !== id);
    saveTasks(tasks);
}

export function toggleTask(id) {
    const tasks = getTasks();
    tasks.forEach(task => {
        if (task.id === id) task.completed = !task.completed;
    });
    saveTasks(tasks);
}

addTask({
    id: Date.now(),
    title: taskInput.value.trim(),
    priority: priority.value,
    category: category.value,
    completed: false,
    duedate: dueDate.value
});