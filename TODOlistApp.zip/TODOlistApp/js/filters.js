export function filterTasks(tasks, type) {
    if (type === "completed") {
        return tasks.filter(t => t.completed);
    }
    if (type === "pending") {
        return tasks.filter(t => !t.completed);
    }
    return tasks;
}

export function searchTasks(tasks, keyword) {
    return tasks.filter(task =>
        task.title.toLowerCase().includes(keyword.toLowerCase())
    );
}
