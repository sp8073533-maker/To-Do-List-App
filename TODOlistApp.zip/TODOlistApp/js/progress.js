export function updateProgress(tasks) {
    const completed = tasks.filter(t => t.completed).length;
    const percent = tasks.length === 0 ? 0 : (completed / tasks.length) * 100;
    document.getElementById("progressBar").style.width = percent + "%";
}
