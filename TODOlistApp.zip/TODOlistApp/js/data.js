const KEY = "todos";

export const getTasks = () =>
    JSON.parse(localStorage.getItem(KEY)) || [];

export const saveTasks = tasks =>
    localStorage.setItem(KEY, JSON.stringify(tasks));
