export function renderTasks(tasks) {
    const list = document.getElementById("taskList");
    list.innerHTML = "";

    tasks.forEach(task => {
        const li = document.createElement("li");
        li.className = `task ${task.completed ? "done" : ""} ${task.priority}`;
        li.dataset.id = task.id;

        li.innerHTML = `
      <span>${task.title}</span>
      <button class="delete">❌</button>
    `;
        list.appendChild(li);
    });                                                                                                                                                                                                                                                                                                                             
}
li.draggable = true;
const today = new Date().toISOString().split("T")[0];

li.innerHTML = `
  <div>
    <span>${task.title}</span>
    <small>
      ${task.category} | ${task.priority}
      ${task.dueDate ? " | Due: " + task.dueDate : ""}
    </small>
  </div>
  <button class="delete">❌</button>
`;

if (task.dueDate && task.dueDate < today && !task.completed) {
    li.classList.add("overdue");
}
 li.className = `task ${task.category} ${task.priority} ${task.completed ? "done" : ""} ${isOverdue(task) ? "overdue" : ""}`;