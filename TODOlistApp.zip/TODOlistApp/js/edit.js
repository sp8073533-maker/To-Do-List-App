import { getTasks, saveTasks } from "./data.js";

export function enableInlineEdit(list) {
    list.addEventListener("dblclick", e => {
        const span = e.target.closest("span");
        if (!span) return;

        const li = span.closest(".task");
        const id = li.dataset.id;
        const oldText = span.innerText;

        const input = document.createElement("input");
        input.value = oldText;

        span.replaceWith(input);
        input.focus();

        input.onblur = () => saveEdit();
        input.onkeydown = e => e.key === "Enter" && saveEdit();

        function saveEdit() {
            const tasks = getTasks();
            const task = tasks.find(t => t.id == id);
            task.title = input.value.trim() || oldText;
            saveTasks(tasks);
            location.reload(); // clean re-render
        }
    });
}
