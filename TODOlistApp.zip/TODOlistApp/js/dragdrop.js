import { getTasks, saveTasks } from "./data.js";

let draggedId = null;

export function enableDragAndDrop(list) {

    list.addEventListener("dragstart", e => {
        draggedId = e.target.dataset.id;
        e.target.classList.add("dragging");
    });

    list.addEventListener("dragend", e => {
        e.target.classList.remove("dragging");
    });

    list.addEventListener("dragover", e => {
        e.preventDefault();
        const target = e.target.closest(".task");
        if (!target || target.dataset.id === draggedId) return;

        const tasks = getTasks();
        const draggedIndex = tasks.findIndex(t => t.id == draggedId);
        const targetIndex = tasks.findIndex(t => t.id == target.dataset.id);

        const [draggedTask] = tasks.splice(draggedIndex, 1);
        tasks.splice(targetIndex, 0, draggedTask);

        saveTasks(tasks);
    });
}
